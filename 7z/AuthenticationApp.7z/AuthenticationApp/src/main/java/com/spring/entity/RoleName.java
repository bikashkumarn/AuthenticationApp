package com.spring.entity;

/**
 * Created by apple on 10/06/17.
 */
public enum RoleName {

    ADMIN, PROJECT_LEAD, DEVELOPER;
}
